// This source code is released under the GPL v3 license, http://www.gnu.org/licenses/gpl.html.
// This file is part of the LNGS project: http://sourceforge.net/projects/lngooglecalsync.

package lnconnectivitytest;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import lotus.domino.*;

// TODO
// o Throw UserException instead of Exception.


public class LNConnectivityTest {
    public static void main(String[] args) throws IOException {
        String javaClassPath = System.getProperty("java.class.path");
        String javaLibPath = System.getProperty("java.library.path");
        String fileSeparator = System.getProperty("file.separator");
        String pathSeparator = System.getProperty("path.separator");
        
        // Get the absolute path to this app
        String loggerFilename = new java.io.File("").getAbsolutePath() + fileSeparator + "lnconntest.log";
        logger = new BufferedWriter(new FileWriter(loggerFilename, true));
        
        printLine("Starting Lotus Notes connectivity test.");

        printLine("");
        printLine("Application Version: " + appVersion);
        printLine("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch"));
        // Display all args that were passed in. They are data values we want to show the user.
        for (String arg : args) {
            printLine(arg.replace(":", ": "));
        }
        printLine("Java: " + System.getProperty("java.version") + " " + System.getProperty("java.vendor"));
        printLine("Java Home: " + System.getProperty("java.home"));
        printLine(newline + "Java Classpath: " + javaClassPath);
        printLine(newline + "Java Library Path: " + javaLibPath);

        printLine("");

        String lnServer = "";
        String lnPassword = "";
        Console console = System.console();

        rc = findNotesIni(javaLibPath, pathSeparator, fileSeparator);

        if (rc == ReturnCode.SUCCESS)
            rc = loadNotesThreadClass();
        if (rc == ReturnCode.SUCCESS)
            rc = initNotesThread();

        if (rc == ReturnCode.SUCCESS) {
            try {
                printLine(newline + "=== Connecting to local sever without specifying a password.");
                Session session = NotesFactory.createSession();
                printLine("Notes version: " + session.getNotesVersion());
                printLine("Platform: " + session.getPlatform());

                String mailfile = session.getEnvironmentString("MailFile", true);

                if (mailfile == null || mailfile.isEmpty())
                    throw new Exception("Couldn't get the mailfile name from notes.ini.");
                printLine("Common user name: " + session.getCommonUserName());
                printLine("KeyFilename: " + session.getEnvironmentString("KeyFilename", true));
                printLine("MailFile: " + mailfile);
                printLine("MailServer: " + session.getEnvironmentString("MailServer", true));
                printLine("Directory: " + session.getEnvironmentString("Directory", true));
                printLine("Success");

                printLine(newline + "=== Connecting to sever with a password.");
                if (lnServer.isEmpty()) {
                    System.out.print("Enter your Lotus Notes server; type \"local\" to use local server> ");
                    lnServer = console.readLine();

                    // Read the password, without echoing the output
                    char[] lnPasswordBuffer = console.readPassword("Enter your Lotus Notes password> ");
                    lnPassword = new String(lnPasswordBuffer);
                }

                // Note: We cast null to a String to avoid overload conflicts
                session = NotesFactory.createSession((String)null, (String)null, lnPassword);
                printLine("Success");

                printLine(newline + "=== Connecting to the Lotus Notes database.");
                String dominoServerTemp = lnServer;
                if (lnServer.equals("local"))
                    dominoServerTemp = null;

                Database db = session.getDatabase(dominoServerTemp, mailfile, false);
                if (db == null) {
                    // Strip off any path info from the mailfile and try to open the DB again
                    int separatorIdx = mailfile.lastIndexOf(File.separator);
                    if (separatorIdx > -1) {
                        String shortMailfile = mailfile.substring(separatorIdx+1);
                        printLine("Using short mailfile name: " + shortMailfile);
                        // Open the DB a slightly different way
                        DbDirectory dbDir = session.getDbDirectory((String)null);
                        db = dbDir.openDatabase(shortMailfile);
                    }                
                }
                if (db == null) {
                    throw new Exception("Couldn't create Lotus Notes Database object." + newline + "Make sure the server name is correct." + newline + "Make sure you have permissions to the .nsf file and that your notes.ini file isn't corrupt.");
                }
                printLine("Success");

                printLine(newline + "=== Querying Lotus Notes calendar.");
                DocumentCollection queryResults = getCalendarEntries(session, db);
                if (queryResults != null) {
                    printLine(queryResults.getCount() + " calendar documents were found.");

                    Document doc;                
                    doc = queryResults.getFirstDocument();                
                    if (doc == null)
                        printLine("WARNING: The first query document is null.");
                    else {
                        printLine("Here are some fields from the first calendar entry found:");

                        Item lnItem;
                        lnItem = doc.getFirstItem("Subject");
                        if (!isItemEmpty(lnItem))
                            printLine("Subject: " + lnItem.getText());

                        lnItem = doc.getFirstItem("StartDateTime");
                        if (!isItemEmpty(lnItem))
                            printLine("Start Date(s): " + lnItem.getText());

                        printLine("Last Modified Date: " + doc.getLastModified().toString());
                        printLine("Success");
                    }
                }
                else {
                    printLine("WARNING: The query result returned null.");
                }
            } catch (Exception ex) {
                printLine("There was a problem reading from the Lotus Notes database.");
                printStackTrace(ex);
                rc = ReturnCode.EXCEPTION;
            } finally {
                NotesThread.stermThread();
            }
        }

        if (rc == ReturnCode.SUCCESS)
            printLine(newline + "=== Connectivity test was successful.");
        else {
            printLine(newline + "=== Connectivity test FAILED!");
            printLine("Try reading the Troubleshooting section of HelpFile.html.");
            printLine("This help file is included with the main LNGS application.");
            printLine("If you need additional help, post to the Open Discussion forum:");
            printLine("https://sourceforge.net/projects/lngooglecalsync/forums");
        }

        if (logger != null) {
            logger.close();
        }

        System.exit(rc.ordinal());
    }


    public static ReturnCode initNotesThread() {
        boolean wasNotesThreadInitialized = false;

        // I don't know why, but if you call NotesThread.sinitThread() in a
        // try/catch block with other statements, then sinitThread() won't
        // throw an exception on error. So, use a separate try/catch block.
        try {
            printLine(newline + "=== Initializing NotesThread.");
            // Make sure your Windows PATH statement includes the location
            // for the Lotus main directory, e.g. "c:\Program Files\Lotus\Notes".
            // This is necessary because the Java classes call native/C dlls in
            // this directory.
            // If the dlls can't be found, then we will drop directly into
            // the finally section (no exception is thrown).  That's strange.
            // So, we set a flag to indicate whether things succeeded or not.
            // Produces deprecation message:
            NotesThread.sinitThread();
            wasNotesThreadInitialized = true;
            printLine("Success");
        } catch (Exception ex) {
            printLine("There was a problem initializing the Lotus Notes thread." + newline + "Make sure the Lotus dll/so/dylib directory is in your path.");
            printStackTrace(ex);
            return ReturnCode.EXCEPTION;
        } finally {
            if (!wasNotesThreadInitialized) {
                return ReturnCode.EXCEPTION;
            }
        }

        return ReturnCode.SUCCESS;
    }


    public static ReturnCode loadNotesThreadClass() {
        try {
            printLine(newline + "=== Trying to manually load NotesThread class.");
            // Some users, especially on OS X, have trouble locating Notes.jar (which
            // needs to be in the classpath) and the supporting dll/so/dylib files (which
            // need to be in the path/ld_library_path).  Try to load one of the Lotus
            // classes to make sure we can find Notes.jar.
            // The next try/catch block (with the sinitThread() call) will check if
            // the supporing dlls can be found.
            ClassLoader.getSystemClassLoader().loadClass("lotus.domino.NotesThread");
            printLine("Success");
        } catch (Exception ex) {
            printLine("The Lotus Notes Java interface file (Notes.jar) could not be found." + newline + "Make sure Notes.jar is in your classpath.");
            printStackTrace(ex);
            return ReturnCode.EXCEPTION;
        }

        return ReturnCode.SUCCESS;
    }


    public static ReturnCode findNotesIni(String javaLibPath, String pathSeparator, String fileSeparator) {
        try {
            printLine(newline + "=== Checking location of notes.ini.");
            // Create a list of File objects. Comparing File objects compares the paths
            // and takes into account case sensitivity of the underlying OS.  Comparing
            // paths as strings is error prone.
            List<File> iniList = new ArrayList<File>();
            String[] libPaths = javaLibPath.split(pathSeparator);
            // Loop through all the library paths looking for notes.ini files
            for (String path : libPaths) {
                if (path.endsWith(fileSeparator)) {
                    // Remove trailing file separator
                    path = path.substring(0, path.length() - 1);
                }
                File f = new File(path + fileSeparator + "notes.ini");
                if (f.exists()) {
                    if (!iniList.contains(f)) {
                        iniList.add(f);
                    }
                }
            }
            for (File iniFile : iniList) {
                printLine("notes.ini file found here: " + iniFile.getAbsolutePath());
            }
            if (iniList.size() < 1) {
                printLine("WARNING: A notes.ini file was not found in the Java Library Path.");
            }
            if (iniList.size() > 1) {
                printLine("WARNING: More than one notes.ini files were found in the Java Library Path.");
                printLine("Deleting unneeded notes.ini files may help resolve some NotesException errors.");
            }
        } catch (Exception ex) {
            printLine("There was an error checking the Java Library Path.");
            printStackTrace(ex);
            return ReturnCode.EXCEPTION;
        }

        return ReturnCode.SUCCESS;
    }

    public static DocumentCollection getCalendarEntries(Session session, Database db) {
        try {
            String strDateFormat;
            // Get the date separator used on the Domino server, e.g. / or -
            String dateSep = session.getInternational().getDateSep();

            // Determine if the server date format is DMY, YMD, or MDY
            if (session.getInternational().isDateDMY()) {
                strDateFormat = "dd" + dateSep + "MM" + dateSep + "yyyy";                
            }
            else if (session.getInternational().isDateYMD()) {
                strDateFormat = "yyyy" + dateSep + "MM" + dateSep + "dd";
            }
            else {
                strDateFormat = "MM" + dateSep + "dd" + dateSep + "yyyy";
            }
            
            DateFormat dateFormat = new SimpleDateFormat(strDateFormat);

            Calendar now = Calendar.getInstance();
            // Clear out the time portion
            now.set(Calendar.HOUR_OF_DAY, 0);
            now.set(Calendar.MINUTE, 0);
            now.set(Calendar.SECOND, 0);
            Date startDate = null;
            startDate = now.getTime();
            // Get 3 months worth of entries
            now.add(Calendar.MONTH, 3);
            Date endDate = now.getTime();
            
            String calendarQuery = "SELECT (@IsAvailable(CalendarDateTime) & (@Explode(CalendarDateTime) *= @Explode(@TextToTime(\"" +
                dateFormat.format(startDate) + " - " + dateFormat.format(endDate) + "\"))))";
            
            DocumentCollection queryResults = db.search(calendarQuery);
            
            return queryResults;
        } catch (Exception ex) {
            printLine("There was an error querying the calendar.");
            printStackTrace(ex);
            return null;
        }
    }

    /**
     * Returns true if the Lotus Notes Item object is empty or null.
     * @param lnItem The object to inspect.
     */
    protected static boolean isItemEmpty(Item lnItem) {
        try {
            // Lotus Notes Item objects are usually read by name, e.g. lnItem = doc.getFirstItem("Subject").
            // If the name doesn't exist at all then null is returned.
            // If the name does exist, but doesn't have a value, then lnItem.getText() returns "".
            // Check for both conditions.
            if (lnItem == null || (lnItem != null && lnItem.getText().isEmpty()))
                return true;            
        } catch (Exception ex) {
            // An error means we couldn't read the Item, so consider it empty
            return true;
        }
        
        return false;
    }
    
    /**
     * Write a message to the console and to a log file.
     */
    protected static void printLine(String sourceString) {
        System.out.println(sourceString);
        
        try {
            logger.write(sourceString + newline);
            logger.flush();
        } catch (IOException e) {
        }
    }
    
    /**
     * Write an exception to the console and to a log file.
     */
    protected static void printStackTrace(Exception ex) {
        StringWriter stackTraceWriter = new StringWriter();
        ex.printStackTrace(new PrintWriter(stackTraceWriter));
        printLine(stackTraceWriter.toString());
    }
        
    final static String appVersion = "1.13";
    final static String newline = System.getProperty("line.separator");

    public enum ReturnCode { SUCCESS, EXCEPTION };
    protected static ReturnCode rc = ReturnCode.SUCCESS;     // Return code
    
    protected static BufferedWriter logger;
}
