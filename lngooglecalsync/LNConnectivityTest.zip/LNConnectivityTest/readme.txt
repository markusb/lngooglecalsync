LN Connectivity Test verifies that a Java application can successfully
connect to Lotus Notes.

To run the app under Windows, use lnconntest.vbs.
To run the app under Linux or OS X, use lnconntest.sh.

The output from running the test will look something like the following.
If you get an error, read the Troubleshooting section of HelpFile.html;
this help file is included with the main LNGS application. 
If you need additional help, post to the Open Discussion forum:
https://sourceforge.net/projects/lngooglecalsync/forums 



========== Output from Successful Test ==========
Starting Lotus Notes connectivity test.

Application Version: 1.7
OS: Windows XP 5.1 x86
Java: 1.6.0_29 Sun Microsystems Inc.
Java Home: c:\Program Files\Java\jre6
Java Classpath: C:\Program Files\Lotus\Notes\\jvm\lib\ext\Notes.jar;.\LNConnectivityTest.j
ar
Java Library Path: c:\Program Files\Java\jre6\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\syste
m32;C:\WINDOWS;C:\Program Files\Lotus\Notes\;C:\Program Files\Lotus\Notes\Data\;
C:\Program Files\Windows Imaging\;c:\Program Files\Lotus\Notes;C:\Program Files\TortoiseSVN
\bin;d:\Util\Dependency Walker;C:\Program Files\QuickTime\QTSystem\


=== Checking location of notes.ini.
notes.ini file found here: C:\Program Files\Lotus\Notes\notes.ini

=== Trying to manually load NotesThread class.
Success

=== Initializing NotesThread.
Success

=== Connecting to local sever without specifying a password.
Notes version: Release 8.5.2FP1 SHF163|March 17, 2011
Platform: Windows/32
Is on server: false
Success

=== Connecting to sever with a password.
Enter your Lotus Notes server (type "local" to use local server)> local
Enter your Lotus Notes password>
Common user name: Dean Hill
KeyFilename: dhill.id
MailFile: mail\deanhill.nsf
MailServer: CN=LN-SRV09/OU=SRV/O=AjaxCompany
Success

=== Connecting to the Lotus Notes database.
Success

=== Connectivity test was successful.
Press any key to continue . . .
