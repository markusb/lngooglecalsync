// This source code is released under the GPL v3 license, http://www.gnu.org/licenses/gpl.html.
// This file is part of the LNGS project: http://sourceforge.net/projects/lngooglecalsync.

package gcalconnectivitytest;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.StoredCredential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.CalendarList;
import com.google.api.services.calendar.model.CalendarListEntry;
import java.io.BufferedWriter;
import java.io.Console;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.regex.Pattern;

// TODO:
// o Change jar paths from absolute to relative.
// o Prompt for proxy info (if not provided on command line).

public class GCalConnectivityTest {
    // It is poor design to throw base Exception objects so use this derived class.
    public static class ApplicationException extends Exception {
        public ApplicationException(String message) {
            super(message);
        }
    }

    public static void main(String[] args) throws IOException {
        String javaClassPath = System.getProperty("java.class.path");
        String javaLibPath = System.getProperty("java.library.path");
        String fileSeparator = System.getProperty("file.separator");
        String pathSeparator = System.getProperty("path.separator");

        // Get the absolute path to this app
        String loggerFilename = new java.io.File("").getAbsolutePath() + fileSeparator + "gcalconntest.log";
        logger = new BufferedWriter(new FileWriter(loggerFilename, true));

        printLine("Starting Google Calendar connectivity test.");

//System.getProperties().put("proxySet", "true");
//System.getProperties().put("proxyHost", "dfw-proxy.ext.ray.com");
//System.getProperties().put("proxyPort", "80");
        
        printLine("");
        printLine("Application Version: " + appVersion);
        printLine("OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " " + System.getProperty("os.arch"));
        printLine("Java: " + System.getProperty("java.version") + " " + System.getProperty("java.vendor"));
        printLine("Java Home: " + System.getProperty("java.home"));
        printLine(newline + "Java Classpath: " + javaClassPath);
        printLine(newline + "Java Library Path: " + javaLibPath);

        printLine("");

        Exception caughtEx = null;
        try {
            Console console = System.console();
            print("Enter your Google ID (usually your GMail address): ");
            googleId = console.readLine();
            
            printLine(newline + newline + "Note: If this is your first time running this application, a web browser window");
            printLine("should open and ask you to allow access to your Google Calendar.");
            printLine("You need to press Accept then return to this window to see the test results.");
            print("Press enter to continue...");
            console.readLine();

            
            printLine(newline + "=== Setting up for test.");
            httpTransport = GoogleNetHttpTransport.newTrustedTransport();

            appPath = new java.io.File("").getAbsolutePath() + System.getProperty("file.separator");
            clientSecrestFullFilename = getClientIdFilename();
            if (clientSecrestFullFilename.isEmpty()) {
                throw new ApplicationException("A Google Client ID file could not be found." +
                        newline + "Read the Installation instructions in the LNGS Help File to learn how to create a Client ID file." + newline);
            }

            // Directory to store user credentials
            java.io.File dataStoreDir = new java.io.File(appPath);
            // Initialize the data store factory
            dataStoreFactory = new FileDataStoreFactory(dataStoreDir);
            printLine("Success");

            printLine(newline + "=== Using Client ID to create credential.");
            Credential credential = authorize();
            printLine("Success");

            printLine(newline + "=== Get list of Google calendars.");
            com.google.api.services.calendar.Calendar client;
            client = new com.google.api.services.calendar.Calendar.Builder(
                httpTransport, JSON_FACTORY, credential).setApplicationName(APPLICATION_NAME).build();

            CalendarList feed = client.calendarList().list().execute();
            if (feed.getItems() != null) {
                int i = 0;
                for (CalendarListEntry entry : feed.getItems()) {
                    i++;
                    printLine("#" + i + " " + entry.getSummary());
                }
            }
            printLine("Success");
        } catch (ApplicationException ex) {
            caughtEx = ex;
        } catch (GeneralSecurityException ex) {
            caughtEx = ex;
        } catch (IOException ex) {
            caughtEx = ex;
        } finally {
            if (caughtEx != null) {
                printLine("There was a problem connecting to Google Calendar.");
                printStackTrace(caughtEx);
                rc = ReturnCode.EXCEPTION;
            }
        }
    
        if (rc == ReturnCode.SUCCESS)
            printLine(newline + "=== Connectivity test was successful.");
        else {
            printLine(newline + "=== Connectivity test FAILED!");
            printLine("Try reading the Troubleshooting section of HelpFile.html.");
            printLine("This help file is included with the main LNGS application.");
            printLine("If you need additional help, post to the Open Discussion forum:");
            printLine("https://sourceforge.net/projects/lngooglecalsync/forums");
        }

        System.exit(rc.ordinal());
    }
    
    // Authorizes the installed application to access user's protected data
    private static Credential authorize() throws IOException {
        // Load client secrets
        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new FileReader(clientSecrestFullFilename));

        GoogleAuthorizationCodeFlow.Builder authBuilder = new GoogleAuthorizationCodeFlow.Builder(
            httpTransport, JSON_FACTORY, clientSecrets,
            Collections.singleton(CalendarScopes.CALENDAR));
        DataStore<StoredCredential> ds = dataStoreFactory.getDataStore(CLIENT_CREDENTIAL_FILENAME);
        GoogleAuthorizationCodeFlow flow = authBuilder.setCredentialDataStore(ds).build();

        return new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize(googleId);
    }

    public static String getClientIdFilename() {
        Pattern pattern = Pattern.compile("^client_secret.*\\.json$");
        
        File dir = new File(appPath);
        
        File[] files = dir.listFiles();
        for (int i = 0; i < files.length; i++) {
            String fileName = files[i].getName();
            if (pattern.matcher(fileName).find()) {
                if (files[i].isFile()) {
                    return files[i].getPath();
                }
            }
        }
        
        return "";
    }

    /**
     * Write a message to the console and to a log file.
     */
    protected static void print(String sourceString) {
        System.out.print(sourceString);
        
        try {
            logger.write(sourceString);
            logger.flush();
        } catch (IOException e) {
        }
    }
    
    /**
     * Write a message to the console and to a log file.
     */
    protected static void printLine(String sourceString) {
        print(sourceString + newline);
    }
    
    /**
     * Write an exception to the console and to a log file.
     */
    protected static void printStackTrace(Exception ex) {
        StringWriter stackTraceWriter = new StringWriter();
        ex.printStackTrace(new PrintWriter(stackTraceWriter));
        printLine(stackTraceWriter.toString());
    }
    
    private static String appPath;
    
    private static final String APPLICATION_NAME = "GCal-Connectivity-Test";
    private static final String CLIENT_CREDENTIAL_FILENAME = "client_credential";

    private static String googleId;
    private static String clientSecrestFullFilename;

    // Global instance of DataStoreFactory
    private static FileDataStoreFactory dataStoreFactory;

    // Global instance of the HTTP transport
    private static HttpTransport httpTransport;
    
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();

    final static String appVersion = "1.2";
    final static String newline = System.getProperty("line.separator");

    public enum ReturnCode { SUCCESS, EXCEPTION };
    protected static ReturnCode rc = ReturnCode.SUCCESS;     // Return code

    protected static BufferedWriter logger;
}
